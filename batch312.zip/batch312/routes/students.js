const express = require('express')

const router = new express.Router()
const student1 = require('../model/student')

router.get('/', async(req, res) => {
    try {
        const s1 = await student1.find()
        res.send('error' + err)
    } catch (err) {
        res.send('error' + err)
    }
})
router.post('/', async(req, res) => {
    const student1 = new student1({
        rollno: req.body.rollno,
        name: req.body.name,
        scholarship: req.body.scholarship
    })

    try {
        const s2 = await student1.save()
        res.json(s2)
    } catch (err) {
        res.send('error' + err)

    }
})
module.exports = router